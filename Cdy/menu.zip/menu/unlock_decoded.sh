red='\e[1;31m'
green='\e[1;32m'
NC='\e[0m'
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
echo -e "\e[32mloading...\e[0m"
clear
nama=$(cat /etc/xray/username)
yellow="\033[0;33m"
ungu="\033[0;35m"
Red="\033[91;1m"
Xark="\033[0m"
BlueCyan="\033[5;36m"
WhiteBe="\033[5;37m"
GreenBe="\033[5;32m"
YellowBe="\033[5;33m"
BlueBe="\033[5;34m"
function baris_panjang() {
echo -e "\033[5;36m ———————————————————————————————————————————————\033[0m"
}
function ARI_Banner() {
baris_panjang
NAMASC="ARISCTUNNEL V4"
function center_text() {
local text="$1"
local width=50  # Sesuaikan dengan panjang baris yang diinginkan
local plain_text=$(echo -e "$text" | sed 's/\x1b\[[0-9;]*m//g')
local len=${#plain_text}
local spaces=$(( (width - len) / 2 ))
printf "%${spaces}s%s\033[0m\n" "" "$(echo -e "$text")"
}
formatted_text="\e[36m.::.\033[0;35m $NAMASC \e[36m.::."
center_text "$formatted_text"
baris_panjang
}
function Sc_Credit(){
sleep 1
baris_panjang
function center_text() {
local text="$1"
local width=50  # Sesuaikan dengan panjang baris yang diinginkan
local plain_text=$(echo -e "$text" | sed 's/\x1b\[[0-9;]*m//g')
local len=${#plain_text}
local spaces=$(( (width - len) / 2 ))
printf "%${spaces}s%s\033[0m\n" "" "$(echo -e "$text")"
}
formatted_text="\033[0;35m Terimakasih sudah menggunakan- \033[0m"
formatted_text1="\033[0;35m Script Credit By $NAMASC \033[0m"
center_text "$formatted_text"
center_text "$formatted_text1"
baris_panjang
}
duration=3
frames=("██10%" "█████35%" "█████████65%" "█████████████80%" "█████████████████████90%" "█████████████████████████100%")
num_frames=${#frames[@]}
num_iterations=$((duration))
Loading_Animasi() {
for ((i = 0; i < num_iterations; i++)); do
clear
index=$((i % num_frames))
color_code=$((31 + i % 7))
echo ""
echo ""
echo ""
echo -e "\e[1;${color_code}m ${frames[$index]}\e[0m"
sleep 0.5
done
}
loading() {
local pid=$1
local delay=0.1
local spin='-\|/'
while ps -p $pid > /dev/null; do
local temp=${spin#?}
printf "[%c] " "$spin"
local spin=$temp${spin%"$temp"}
sleep $delay
printf "\b\b\b\b\b\b"
done
printf "    \b\b\b\b"
}
function Loading_Succes() {
clear
echo -e  "\033[5;32mSucces\033[0m"
sleep 1
clear
}
clear
echo -e "\033[5;36m┌──────────────────────────────────────────┐\033[0m"
echo "   USERNAME       EXP DATE         STATUS"
echo -e "\033[5;36m└──────────────────────────────────────────┘\033[0m"
echo -e "\033[5;36m┌──────────────────────────────────────────┐\033[0m"
while read expired
do
AKUN="$(echo $expired | cut -d: -f1)"
ID="$(echo $expired | grep -v nobody | cut -d: -f3)"
exp="$(chage -l $AKUN | grep "Account expires" | awk -F": " '{print $2}')"
status="$(passwd -S $AKUN | awk '{print $2}' )"
if [[ $ID -ge 1000 ]]; then
if [[ "$status" = "L" ]]; then
printf "%-17s %2s %-17s %2s \n" "  $AKUN" "$exp   " "LOCKED${NORMAL}"
fi
fi
done < /etc/passwd
JUMLAH="$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd | wc -l)"
echo -e "\033[5;36m└──────────────────────────────────────────┘\033[0m"
echo -e "\033[5;36m┌──────────────────────────────────────────┐\033[0m"
echo "   Account number: $JUMLAH   user"
echo -e "\033[5;36m└──────────────────────────────────────────┘\033[0m"
echo " "
echo " "
read -p "Input Username To Unlock :   " username
sleep 3 & loading $!
Loading_Succes
egrep "^$username" /etc/passwd >/dev/null
if [ $? -eq 0 ]; then
passwd -u $username
clear
ARI_Banner
echo " "
baris_panjang
echo ""
echo -e "${GreenBe} successfully ${Xark}"
echo ""
echo -e "${Cyan} Username  : $username${Xark}"
echo -e "${Cyan} Status    : Unlock ${Xark} "
echo ""
baris_panjang
Sc_Credit
read -n 1 -s -r -p " Press Enter for Back to Manage"
bash /usr/bin/m-ssh
else
echo " "
echo -e "Username ${red}$username${NC} not found in your server."
echo " "
fi